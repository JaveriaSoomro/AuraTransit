"use client";

import React, { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { LogoMark } from "@/components/logo";
import { Input } from "@/components/ui/form-field";
import { Button } from "@/components/ui/button";
import { ArrowRight, Check } from "lucide-react";

export default function RegisterPage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [schoolName, setSchoolName] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    router.push("/verify-email");
  };

  return (
    <div className="min-h-screen bg-ivory flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <Link href="/" className="inline-flex items-center gap-2.5">
          <LogoMark className="h-10 w-10" />
          <span className="text-xl font-bold tracking-[0.16em] text-teal">
            AURATRANSIT
          </span>
        </Link>
        <h2 className="mt-6 text-2xl sm:text-3xl font-bold tracking-tight text-ink">
          Connect your school
        </h2>
        <p className="mt-1 text-sm text-ink/55">
          Launch modern, calm school transportation operations
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4">
        <div className="rounded-[36px] border border-ink/8 bg-white p-7 sm:p-9 shadow-xl space-y-5">
          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              label="School / Institution Name"
              placeholder="e.g. Westlake Academy"
              value={schoolName}
              onChange={(e) => setSchoolName(e.target.value)}
              required
            />
            <Input
              label="Administrator Name"
              placeholder="e.g. Dr. Emily Vance"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
            <Input
              label="Official School Email"
              type="email"
              placeholder="e.vance@westlake.org"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <Input
              label="Create Secure Password"
              type="password"
              placeholder="At least 8 characters"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />

            <Button
              type="submit"
              variant="primary"
              className="w-full py-3 mt-2"
              icon={<ArrowRight className="h-4 w-4" />}
            >
              Start Free Operations Trial
            </Button>
          </form>

          <div className="border-t border-ink/8 pt-4 text-center">
            <p className="text-xs text-ink/50">
              Already have an account?{" "}
              <Link href="/login" className="font-semibold text-teal hover:underline">
                Sign in
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
