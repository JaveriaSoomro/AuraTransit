"use client";

import React, { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { LogoMark } from "@/components/logo";
import { Input } from "@/components/ui/form-field";
import { Button } from "@/components/ui/button";

export default function ResetPasswordPage() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    router.push("/login");
  };

  return (
    <div className="min-h-screen bg-ivory flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <Link href="/" className="inline-flex items-center gap-2.5">
          <LogoMark className="h-10 w-10" />
          <span className="text-xl font-bold tracking-[0.16em] text-teal">
            AURATRANSIT
          </span>
        </Link>
        <h2 className="mt-6 text-2xl sm:text-3xl font-bold tracking-tight text-ink">
          Set new password
        </h2>
        <p className="mt-1 text-sm text-ink/55">
          Must be at least 8 characters with letters and numbers
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4">
        <div className="rounded-[36px] border border-ink/8 bg-white p-7 sm:p-9 shadow-xl space-y-5">
          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              label="New Password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <Input
              label="Confirm New Password"
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
            />

            <Button type="submit" variant="primary" className="w-full py-3">
              Update Password & Sign In
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
