"use client";

import React, { useState, useMemo } from "react";
import { ShieldCheck } from "lucide-react";
import { useAuraStore } from "@/lib/store";
import { Aide } from "@/types/dashboard";
import { PageHeader } from "@/components/layout/page-header";
import { FilterBar } from "@/components/layout/filter-bar";
import { DataTable, Column } from "@/components/layout/data-table";
import { StatusBadge } from "@/components/ui/status-badge";

export default function SuperAdminAidesPage() {
  const { aides } = useAuraStore();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const filteredData = useMemo(() => {
    return aides.filter((a) => {
      const matchesSearch =
        a.name.toLowerCase().includes(search.toLowerCase()) ||
        a.certification.toLowerCase().includes(search.toLowerCase());
      const matchesStatus =
        statusFilter === "all" || a.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [aides, search, statusFilter]);

  const columns: Column<Aide>[] = [
    {
      key: "name",
      header: "Aide",
      render: (a) => (
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-aura/20 text-teal font-bold text-xs shrink-0">
            {a.name.split(" ").map((n) => n[0]).join("")}
          </div>
          <div>
            <p className="font-semibold text-ink">{a.name}</p>
            <p className="text-xs text-ink/50">{a.email}</p>
          </div>
        </div>
      ),
    },
    {
      key: "school",
      header: "Assigned Campus",
      render: (a) => (
        <span className="text-xs text-ink font-medium">
          Lincoln International School
        </span>
      ),
    },
    {
      key: "certification",
      header: "Certifications",
      render: (a) => (
        <span className="text-xs text-ink/75">{a.certification}</span>
      ),
    },
    {
      key: "status",
      header: "Status",
      render: (a) => <StatusBadge status={a.status} />,
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Global Transportation Aides"
        description="Monitor certified student monitors and health/mobility aides across all affiliated campuses."
      />

      <FilterBar
        searchValue={search}
        onSearchChange={setSearch}
        searchPlaceholder="Search aides across platform..."
        totalResults={filteredData.length}
        onResetFilters={() => {
          setSearch("");
          setStatusFilter("all");
        }}
        filters={[
          {
            key: "status",
            label: "Status",
            value: statusFilter,
            onChange: setStatusFilter,
            options: [
              { label: "All Statuses", value: "all" },
              { label: "Active", value: "active" },
              { label: "On Duty", value: "on_duty" },
              { label: "Off Duty", value: "off_duty" },
            ],
          },
        ]}
      />

      <DataTable
        columns={columns}
        data={filteredData}
        keyExtractor={(a) => a.id}
      />
    </div>
  );
}
