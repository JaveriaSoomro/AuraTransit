"use client";

import React, { useState, useMemo } from "react";
import { GitFork } from "lucide-react";
import { useAuraStore } from "@/lib/store";
import { Route } from "@/types/dashboard";
import { PageHeader } from "@/components/layout/page-header";
import { FilterBar } from "@/components/layout/filter-bar";
import { DataTable, Column } from "@/components/layout/data-table";
import { StatusBadge } from "@/components/ui/status-badge";

export default function SuperAdminRoutesPage() {
  const { routes } = useAuraStore();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const filteredData = useMemo(() => {
    return routes.filter((r) => {
      const matchesSearch =
        r.routeNumber.toLowerCase().includes(search.toLowerCase()) ||
        r.name.toLowerCase().includes(search.toLowerCase());
      const matchesStatus =
        statusFilter === "all" || r.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [routes, search, statusFilter]);

  const columns: Column<Route>[] = [
    {
      key: "routeNumber",
      header: "Route",
      render: (r) => (
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-sun/20 text-ink font-bold text-xs shrink-0">
            <GitFork className="h-4 w-4 text-teal" />
          </div>
          <div>
            <p className="font-bold text-ink">{r.routeNumber}</p>
            <p className="text-xs text-ink/55">{r.name}</p>
          </div>
        </div>
      ),
    },
    {
      key: "school",
      header: "School District",
      render: () => (
        <span className="text-xs text-ink font-medium">
          Lincoln International School
        </span>
      ),
    },
    {
      key: "assignedVehicleNumber",
      header: "Vehicle",
      render: (r) => (
        <span className="text-xs font-semibold text-teal">
          {r.assignedVehicleNumber || "Unassigned"}
        </span>
      ),
    },
    {
      key: "studentsCount",
      header: "Students",
      render: (r) => (
        <span className="text-xs font-bold text-ink">{r.studentsCount}</span>
      ),
    },
    {
      key: "status",
      header: "Status",
      render: (r) => <StatusBadge status={r.status} />,
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Global Routes Management"
        description="Monitor active school transportation routes and district corridors across the network."
      />

      <FilterBar
        searchValue={search}
        onSearchChange={setSearch}
        searchPlaceholder="Search routes across network..."
        totalResults={filteredData.length}
        onResetFilters={() => {
          setSearch("");
          setStatusFilter("all");
        }}
        filters={[
          {
            key: "status",
            label: "Status",
            value: statusFilter,
            onChange: setStatusFilter,
            options: [
              { label: "All Statuses", value: "all" },
              { label: "In Progress", value: "in_progress" },
              { label: "Scheduled", value: "scheduled" },
              { label: "Delayed", value: "delayed" },
              { label: "Completed", value: "completed" },
            ],
          },
        ]}
      />

      <DataTable
        columns={columns}
        data={filteredData}
        keyExtractor={(r) => r.id}
      />
    </div>
  );
}
