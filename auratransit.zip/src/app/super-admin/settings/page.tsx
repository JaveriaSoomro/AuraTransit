"use client";

import React, { useState } from "react";
import {
  Shield,
  Key,
  Globe,
  Bell,
  Save,
  CheckCircle2,
  Lock,
} from "lucide-react";
import { PageHeader } from "@/components/layout/page-header";
import { Button } from "@/components/ui/button";
import { Input, Select } from "@/components/ui/form-field";
import { useToast } from "@/components/ui/toast";

export default function SuperAdminSettingsPage() {
  const { showToast } = useToast();
  const [name, setName] = useState("AuraTransit Platform Director");
  const [email, setEmail] = useState("admin@auratransit.com");
  const [phone, setPhone] = useState("+1 (800) 555-0100");
  const [tfaEnabled, setTfaEnabled] = useState(true);
  const [timezone, setTimezone] = useState("UTC");

  const handleSave = () => {
    showToast("Global platform settings updated.");
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <PageHeader
        title="Platform Settings & Security"
        description="Global system configuration, administrative two-factor authentication, active API sessions, and regional localization defaults."
        actions={
          <Button
            variant="primary"
            icon={<Save className="h-4 w-4" />}
            onClick={handleSave}
          >
            Save Global Settings
          </Button>
        }
      />

      <div className="space-y-6">
        {/* Profile Card */}
        <div className="rounded-[32px] border border-ink/8 bg-white p-6 sm:p-8 shadow-xs space-y-4">
          <h3 className="text-base font-semibold text-ink">
            Super Administrator Profile
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="Director Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
            <Input
              label="System Operations Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <Input
            label="Direct Emergency Hotline"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
          />
        </div>

        {/* Security & 2FA */}
        <div className="rounded-[32px] border border-ink/8 bg-white p-6 sm:p-8 shadow-xs space-y-4">
          <div className="flex items-center gap-2">
            <Lock className="h-5 w-5 text-teal" />
            <h3 className="text-base font-semibold text-ink">
              Platform Security & 2FA Enforcement
            </h3>
          </div>
          <p className="text-xs text-ink/50">
            Enforce multi-factor verification for all school administration logins.
          </p>

          <div className="flex items-center justify-between rounded-2xl border border-ink/8 bg-ivory/60 p-4">
            <div>
              <p className="text-xs font-bold text-ink">
                Mandatory 2FA For All School Admins
              </p>
              <p className="text-[11px] text-ink/55 mt-0.5">
                Requires hardware key or authenticator app (TOTP)
              </p>
            </div>
            <label className="relative inline-flex cursor-pointer items-center">
              <input
                type="checkbox"
                checked={tfaEnabled}
                onChange={(e) => setTfaEnabled(e.target.checked)}
                className="peer sr-only"
              />
              <div className="h-6 w-11 rounded-full bg-ink/20 peer-checked:bg-teal transition-colors peer-checked:after:translate-x-full after:absolute after:top-0.5 after:left-[2px] after:h-5 after:w-5 after:rounded-full after:bg-white after:transition-all" />
            </label>
          </div>

          <div className="rounded-2xl border border-ink/8 bg-white p-4 space-y-2 text-xs">
            <span className="font-bold text-ink block">Active System Sessions</span>
            <div className="flex items-center justify-between py-1 text-ink/75">
              <span>Primary Gateway (Chicago, US) · Chrome Mac</span>
              <span className="text-aura font-bold">Current Session</span>
            </div>
          </div>
        </div>

        {/* Regional Preferences */}
        <div className="rounded-[32px] border border-ink/8 bg-white p-6 sm:p-8 shadow-xs space-y-4">
          <div className="flex items-center gap-2">
            <Globe className="h-5 w-5 text-teal" />
            <h3 className="text-base font-semibold text-ink">
              Localization & Preferences
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Select
              label="Default Platform Timezone"
              value={timezone}
              onChange={(e) => setTimezone(e.target.value)}
              options={[
                { label: "Coordinated Universal Time (UTC)", value: "UTC" },
                { label: "America/Chicago (CST)", value: "America/Chicago (CST)" },
                { label: "America/New_York (EST)", value: "America/New_York (EST)" },
              ]}
            />
            <Select
              label="Telemetry Units"
              value="imperial"
              onChange={() => {}}
              options={[
                { label: "Imperial (Miles / MPH)", value: "imperial" },
                { label: "Metric (Kilometers / KPH)", value: "metric" },
              ]}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
