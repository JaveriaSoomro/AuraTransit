"use client";

import React, { useState, useMemo } from "react";
import { Bus } from "lucide-react";
import { useAuraStore } from "@/lib/store";
import { Vehicle } from "@/types/dashboard";
import { PageHeader } from "@/components/layout/page-header";
import { FilterBar } from "@/components/layout/filter-bar";
import { DataTable, Column } from "@/components/layout/data-table";
import { StatusBadge } from "@/components/ui/status-badge";

export default function SuperAdminVehiclesPage() {
  const { vehicles } = useAuraStore();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const filteredData = useMemo(() => {
    return vehicles.filter((v) => {
      const matchesSearch =
        v.vehicleNumber.toLowerCase().includes(search.toLowerCase()) ||
        v.registrationNumber.toLowerCase().includes(search.toLowerCase());
      const matchesStatus =
        statusFilter === "all" || v.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [vehicles, search, statusFilter]);

  const columns: Column<Vehicle>[] = [
    {
      key: "vehicleNumber",
      header: "Vehicle",
      render: (v) => (
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-teal/10 text-teal shrink-0">
            <Bus className="h-4 w-4" />
          </div>
          <div>
            <p className="font-bold text-ink">{v.vehicleNumber}</p>
            <p className="text-xs text-ink/50">{v.model}</p>
          </div>
        </div>
      ),
    },
    {
      key: "school",
      header: "Assigned Tenant",
      render: () => (
        <span className="text-xs text-ink font-medium">
          Lincoln International School
        </span>
      ),
    },
    {
      key: "type",
      header: "Type",
      render: (v) => <span className="text-xs text-ink/80">{v.type}</span>,
    },
    {
      key: "capacity",
      header: "Capacity",
      render: (v) => (
        <span className="text-xs font-semibold text-ink">
          {v.capacity} seats
        </span>
      ),
    },
    {
      key: "driver",
      header: "Assigned Driver",
      render: (v) => (
        <span className="text-xs text-ink">{v.assignedDriverName || "Unassigned"}</span>
      ),
    },
    {
      key: "status",
      header: "Status",
      render: (v) => <StatusBadge status={v.status} />,
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Global Fleet Registry"
        description="Unified vehicle inventory across all participating educational institutions."
      />

      <FilterBar
        searchValue={search}
        onSearchChange={setSearch}
        searchPlaceholder="Search all vehicles across network..."
        totalResults={filteredData.length}
        onResetFilters={() => {
          setSearch("");
          setStatusFilter("all");
        }}
        filters={[
          {
            key: "status",
            label: "Status",
            value: statusFilter,
            onChange: setStatusFilter,
            options: [
              { label: "All Statuses", value: "all" },
              { label: "Active", value: "active" },
              { label: "On Route", value: "on_route" },
              { label: "At Stop", value: "at_stop" },
              { label: "Delayed", value: "delayed" },
              { label: "Maintenance", value: "maintenance" },
            ],
          },
        ]}
      />

      <DataTable
        columns={columns}
        data={filteredData}
        keyExtractor={(v) => v.id}
      />
    </div>
  );
}
