"use client";

import React, { useState, useMemo } from "react";
import { HeartHandshake, Bell } from "lucide-react";
import { useAuraStore } from "@/lib/store";
import { Parent } from "@/types/dashboard";
import { PageHeader } from "@/components/layout/page-header";
import { FilterBar } from "@/components/layout/filter-bar";
import { DataTable, Column } from "@/components/layout/data-table";
import { StatusBadge } from "@/components/ui/status-badge";

export default function SuperAdminParentsPage() {
  const { parents } = useAuraStore();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const filteredData = useMemo(() => {
    return parents.filter((p) => {
      const matchesSearch =
        p.name.toLowerCase().includes(search.toLowerCase()) ||
        p.email.toLowerCase().includes(search.toLowerCase());
      const matchesStatus =
        statusFilter === "all" || p.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [parents, search, statusFilter]);

  const columns: Column<Parent>[] = [
    {
      key: "name",
      header: "Parent / Guardian",
      render: (p) => (
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-teal text-white font-bold text-xs shrink-0">
            {p.name.split(" ").map((n) => n[0]).join("")}
          </div>
          <div>
            <p className="font-semibold text-ink">{p.name}</p>
            <p className="text-xs text-ink/50">{p.email}</p>
          </div>
        </div>
      ),
    },
    {
      key: "school",
      header: "School",
      render: () => (
        <span className="text-xs text-ink font-medium">
          Lincoln International School
        </span>
      ),
    },
    {
      key: "students",
      header: "Enrolled Riders",
      render: (p) => (
        <span className="text-xs font-semibold text-teal">
          {p.studentNames.join(", ")}
        </span>
      ),
    },
    {
      key: "notificationStatus",
      header: "Channel",
      render: (p) => (
        <span className="text-xs text-ink/75 font-mono">
          {p.notificationStatus}
        </span>
      ),
    },
    {
      key: "status",
      header: "Status",
      render: (p) => <StatusBadge status={p.status} />,
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Global Guardians Directory"
        description="Unified registry of all verified parent and guardian accounts connected to AuraTransit."
      />

      <FilterBar
        searchValue={search}
        onSearchChange={setSearch}
        searchPlaceholder="Search parents across network..."
        totalResults={filteredData.length}
        onResetFilters={() => {
          setSearch("");
          setStatusFilter("all");
        }}
        filters={[
          {
            key: "status",
            label: "Status",
            value: statusFilter,
            onChange: setStatusFilter,
            options: [
              { label: "All Statuses", value: "all" },
              { label: "Active", value: "active" },
              { label: "Inactive", value: "inactive" },
            ],
          },
        ]}
      />

      <DataTable
        columns={columns}
        data={filteredData}
        keyExtractor={(p) => p.id}
      />
    </div>
  );
}
