"use client";

import React, { useState, useMemo } from "react";
import { UserCheck, Star, Eye } from "lucide-react";
import { useAuraStore } from "@/lib/store";
import { Driver } from "@/types/dashboard";
import { PageHeader } from "@/components/layout/page-header";
import { FilterBar } from "@/components/layout/filter-bar";
import { DataTable, Column } from "@/components/layout/data-table";
import { StatusBadge } from "@/components/ui/status-badge";

export default function SuperAdminDriversPage() {
  const { drivers, schools } = useAuraStore();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const filteredData = useMemo(() => {
    return drivers.filter((d) => {
      const matchesSearch =
        d.name.toLowerCase().includes(search.toLowerCase()) ||
        d.licenseNumber.toLowerCase().includes(search.toLowerCase());
      const matchesStatus =
        statusFilter === "all" || d.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [drivers, search, statusFilter]);

  const columns: Column<Driver>[] = [
    {
      key: "name",
      header: "Driver",
      render: (d) => (
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-sun text-ink font-bold text-xs shrink-0">
            {d.name.split(" ").map((n) => n[0]).join("")}
          </div>
          <div>
            <p className="font-semibold text-ink">{d.name}</p>
            <p className="text-xs text-ink/50">{d.email}</p>
          </div>
        </div>
      ),
    },
    {
      key: "school",
      header: "Assigned School",
      render: (d) => (
        <span className="text-xs text-ink font-medium">
          Lincoln International School
        </span>
      ),
    },
    {
      key: "license",
      header: "License Number",
      render: (d) => (
        <span className="font-mono text-xs text-ink/75 bg-ivory px-2 py-0.5 rounded border border-ink/8">
          {d.licenseNumber}
        </span>
      ),
    },
    {
      key: "trips",
      header: "Completed Trips",
      render: (d) => (
        <span className="text-xs font-bold text-ink">{d.tripsCount}</span>
      ),
    },
    {
      key: "rating",
      header: "Rating",
      render: (d) => (
        <div className="flex items-center gap-1 text-xs font-bold text-ink">
          <Star className="h-3 w-3 fill-sun text-sun" />
          <span>{d.rating}</span>
        </div>
      ),
    },
    {
      key: "status",
      header: "Status",
      render: (d) => <StatusBadge status={d.status} />,
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Global Driver Roster"
        description="Platform-wide monitoring of certified school bus drivers across all partner school districts."
      />

      <FilterBar
        searchValue={search}
        onSearchChange={setSearch}
        searchPlaceholder="Search all drivers across network..."
        totalResults={filteredData.length}
        onResetFilters={() => {
          setSearch("");
          setStatusFilter("all");
        }}
        filters={[
          {
            key: "status",
            label: "Status",
            value: statusFilter,
            onChange: setStatusFilter,
            options: [
              { label: "All Statuses", value: "all" },
              { label: "Active", value: "active" },
              { label: "On Trip", value: "on_trip" },
              { label: "Off Duty", value: "off_duty" },
            ],
          },
        ]}
      />

      <DataTable
        columns={columns}
        data={filteredData}
        keyExtractor={(d) => d.id}
      />
    </div>
  );
}
