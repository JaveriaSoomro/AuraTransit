"use client";

import React, { useState, useMemo } from "react";
import { GraduationCap } from "lucide-react";
import { useAuraStore } from "@/lib/store";
import { Student } from "@/types/dashboard";
import { PageHeader } from "@/components/layout/page-header";
import { FilterBar } from "@/components/layout/filter-bar";
import { DataTable, Column } from "@/components/layout/data-table";
import { StatusBadge } from "@/components/ui/status-badge";

export default function SuperAdminStudentsPage() {
  const { students } = useAuraStore();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const filteredData = useMemo(() => {
    return students.filter((s) => {
      const fullName = `${s.firstName} ${s.lastName}`.toLowerCase();
      const matchesSearch =
        fullName.includes(search.toLowerCase()) ||
        s.studentId.toLowerCase().includes(search.toLowerCase());
      const matchesStatus =
        statusFilter === "all" || s.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [students, search, statusFilter]);

  const columns: Column<Student>[] = [
    {
      key: "student",
      header: "Student",
      render: (s) => (
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-sun text-ink font-bold text-xs shrink-0">
            {s.firstName[0]}
            {s.lastName[0]}
          </div>
          <div>
            <p className="font-semibold text-ink">
              {s.firstName} {s.lastName}
            </p>
            <p className="font-mono text-xs text-ink/45">{s.studentId}</p>
          </div>
        </div>
      ),
    },
    {
      key: "school",
      header: "Enrolled Campus",
      render: () => (
        <span className="text-xs text-ink font-medium">
          Lincoln International School
        </span>
      ),
    },
    {
      key: "grade",
      header: "Grade",
      render: (s) => (
        <span className="text-xs font-semibold text-ink/75 bg-ivory px-2 py-0.5 rounded border border-ink/8">
          {s.grade}
        </span>
      ),
    },
    {
      key: "parentName",
      header: "Parent / Guardian",
      render: (s) => (
        <span className="text-xs text-ink/80">{s.parentName}</span>
      ),
    },
    {
      key: "status",
      header: "Boarding Status",
      render: (s) => <StatusBadge status={s.status} />,
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Global Student Registry"
        description="Comprehensive rider directory covering all enrolled students across participating educational districts."
      />

      <FilterBar
        searchValue={search}
        onSearchChange={setSearch}
        searchPlaceholder="Search students across network..."
        totalResults={filteredData.length}
        onResetFilters={() => {
          setSearch("");
          setStatusFilter("all");
        }}
        filters={[
          {
            key: "status",
            label: "Status",
            value: statusFilter,
            onChange: setStatusFilter,
            options: [
              { label: "All Statuses", value: "all" },
              { label: "On Board", value: "on_board" },
              { label: "Dropped Off", value: "dropped_off" },
              { label: "Active", value: "active" },
              { label: "Absent", value: "absent" },
            ],
          },
        ]}
      />

      <DataTable
        columns={columns}
        data={filteredData}
        keyExtractor={(s) => s.id}
      />
    </div>
  );
}
