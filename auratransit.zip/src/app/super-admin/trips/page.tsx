"use client";

import React, { useState, useMemo } from "react";
import { History, Download, FileSpreadsheet } from "lucide-react";
import { useAuraStore } from "@/lib/store";
import { TripHistoryItem } from "@/types/dashboard";
import { PageHeader } from "@/components/layout/page-header";
import { FilterBar } from "@/components/layout/filter-bar";
import { DataTable, Column } from "@/components/layout/data-table";
import { StatusBadge } from "@/components/ui/status-badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/toast";

export default function SuperAdminTripsPage() {
  const { trips } = useAuraStore();
  const { showToast } = useToast();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const filteredData = useMemo(() => {
    return trips.filter((t) => {
      const matchesSearch =
        t.tripNumber.toLowerCase().includes(search.toLowerCase()) ||
        t.routeName.toLowerCase().includes(search.toLowerCase()) ||
        t.driverName.toLowerCase().includes(search.toLowerCase());
      const matchesStatus =
        statusFilter === "all" || t.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [trips, search, statusFilter]);

  const handleExport = () => {
    showToast("Exporting multi-district trip telemetry log...");
  };

  const columns: Column<TripHistoryItem>[] = [
    {
      key: "date",
      header: "Run / Date",
      render: (t) => (
        <div>
          <p className="font-semibold text-ink">{t.date}</p>
          <p className="font-mono text-xs text-ink/45">{t.tripNumber}</p>
        </div>
      ),
    },
    {
      key: "school",
      header: "Institution",
      render: () => (
        <span className="text-xs font-medium text-ink">
          Lincoln International School
        </span>
      ),
    },
    {
      key: "routeName",
      header: "Route",
      render: (t) => (
        <span className="text-xs font-semibold text-teal">{t.routeName}</span>
      ),
    },
    {
      key: "driverName",
      header: "Driver",
      render: (t) => <span className="text-xs text-ink">{t.driverName}</span>,
    },
    {
      key: "vehicleNumber",
      header: "Cab",
      render: (t) => (
        <span className="font-mono text-xs text-ink/75 bg-ivory px-2 py-0.5 rounded border border-ink/8">
          {t.vehicleNumber}
        </span>
      ),
    },
    {
      key: "status",
      header: "Status",
      render: (t) => <StatusBadge status={t.status} />,
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Cross-Tenant Trips & Audit Logs"
        description="System-wide operational log tracking all scheduled runs, on-time arrivals, and traffic incidents."
        actions={
          <Button
            variant="secondary"
            size="sm"
            icon={<FileSpreadsheet className="h-4 w-4 text-teal" />}
            onClick={handleExport}
          >
            Export Global Log
          </Button>
        }
      />

      <FilterBar
        searchValue={search}
        onSearchChange={setSearch}
        searchPlaceholder="Search trips by ID, route, or driver..."
        totalResults={filteredData.length}
        onResetFilters={() => {
          setSearch("");
          setStatusFilter("all");
        }}
        filters={[
          {
            key: "status",
            label: "Status",
            value: statusFilter,
            onChange: setStatusFilter,
            options: [
              { label: "All Statuses", value: "all" },
              { label: "Completed", value: "completed" },
              { label: "In Progress", value: "in_progress" },
              { label: "Delayed", value: "delayed" },
            ],
          },
        ]}
      />

      <DataTable
        columns={columns}
        data={filteredData}
        keyExtractor={(t) => t.id}
      />
    </div>
  );
}
